import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Constants
WIDTH = 800
HEIGHT = 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("الرجل العكنبوت")
clock = pygame.time.Clock() # Set the clock for controlling the frame rate
# Set the frame rate
FPS = 60

# Colors
BLACK = (0, 0, 0)
RED = (255, 50, 50)
GRAY = (180, 180, 180)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BRIGHT_RED = (255, 0, 0)

# Load images
background_image = pygame.image.load(r'C:\Users\alghad\Documents\Computer Graphics\graphic project\everest-4828404_640.webp')
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT)) # Scale to fit the screen
# Scale the background image to fit the screen

player_image = pygame.image.load(r'C:\Users\alghad\Documents\Computer Graphics\graphic project\download.png')
player_image = pygame.transform.scale(player_image, (70, 70))

ston_image = pygame.image.load(r'C:\Users\alghad\Documents\Computer Graphics\graphic project\Stone-versatile-and-natural-element-transparent-PNG-image-jpg-768x768.png')
ston_image = pygame.transform.scale(ston_image, (60, 40))

star_image = pygame.image.load(r'C:\Users\alghad\Documents\Computer Graphics\graphic project\—Pngtree—star cartoon stars cute stars_3816650.png')
star_image = pygame.transform.scale(star_image, (50, 50))

# Fonts
font = pygame.font.SysFont(None, 36) # Font for score display
game_over_font = pygame.font.SysFont(None, 72) # Font for game over display
button_font = pygame.font.SysFont(None, 48) # Font for button text

# Player setup
player_full_width, player_full_height = 40, 40  # Player image size
player_collision_width, player_collision_height = 28, 28  # Collision box size
player_x = WIDTH // 2 - player_full_width // 2  # Initial player x position
player_y = 150  # Initial player y position
player_rect = pygame.Rect(player_x + 6, player_y + 6, player_collision_width, player_collision_height)  # Player collision rect
player_speed_x = 5  # Player speed

# Obstacle setup
ston_width, ston_height = 50, 20  # Collision box size for ston
ston_speed = 5
stons = []
ston_timer = 0

def create_stons():
    x = random.randint(0, WIDTH - ston_width)
    y = HEIGHT + random.randint(20, 100)
    return pygame.Rect(x, y, ston_width, ston_height)


for _ in range(5):
    stons.append(create_stons())

# Star setup
star_size = 20
stars = []

def create_star():
    x = random.randint(0, WIDTH - star_size)
    y = HEIGHT + random.randint(100, 400)
    return pygame.Rect(x, y, star_size, star_size)

for _ in range(3):
    stars.append(create_star())

# Load sounds
star_collect_sound = pygame.mixer.Sound(r"C:\Users\alghad\Documents\Computer Graphics\graphic project\coin-recieved-230517.mp3")
game_over_sound = pygame.mixer.Sound(r"C:\Users\alghad\Documents\Computer Graphics\graphic project\game-over-2-sound-effect-230463.mp3")

# Score
score = 0
star_score = 0
game_over_displayed = False

def reset_game():
    global score, star_score, player_rect, stons, stars, game_over_displayed  # Reset game variables
    score = 0
    star_score = 0
    player_rect = pygame.Rect(WIDTH // 2 - player_full_width // 2 + 6, 150 + 6, player_collision_width, player_collision_height)  # Reset player position
    stons.clear()
    for _ in range(5):
        stons.append(create_stons())
    stars.clear()
    for _ in range(3):
        stars.append(create_star())
    game_over_displayed = False

# Game loop
running = True
while running:
    clock.tick(FPS) #
    score += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if not game_over_displayed:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_rect.left > 0:
            player_rect.x -= player_speed_x  # Move left
        if keys[pygame.K_RIGHT] and player_rect.right < WIDTH:
            player_rect.x += player_speed_x  # Move right

        # Move obstacles upward
        for obs in stons:
            obs.y -= ston_speed
            if obs.y + ston_height < 0:
                obs.y = HEIGHT + random.randint(20, 100)
                obs.x = random.randint(0, WIDTH - ston_width)
            if player_rect.colliderect(obs):
                if not game_over_displayed:
                    game_over_sound.play()
                    pygame.time.delay(int(game_over_sound.get_length() * 1000))
                    game_over_displayed = True
                    continue

        # Move stars upward
        for star in stars:
            star.y -= ston_speed
            if star.y + star_size < 0:
                star.y = HEIGHT + random.randint(100, 400)
                star.x = random.randint(0, WIDTH - star_size)
            if player_rect.colliderect(star):
                star_score += 50
                stars.remove(star)
                stars.append(create_star())
                star_collect_sound.play()

        # Draw everything
        screen.blit(background_image, (0, 0))
        screen.blit(player_image, (player_rect.x - 6, player_rect.y - 6))  # Adjust player image

        for ston in stons:
            screen.blit(ston_image, (ston.x - 5, ston.y - 10))  # Adjust so it looks centered

        for star in stars:
            screen.blit(star_image, (star.x , star.y ))  # Adjust so it looks centered

        # Draw score
        score_text = font.render(f"Score: {score}", True, WHITE)
        bonus_text = font.render(f"Stars: {star_score}", True, YELLOW)
        screen.blit(score_text, (10, 10))
        screen.blit(bonus_text, (10, 40))

    else:
        # Draw Game Over screen
        screen.blit(background_image, (0, 0))
        game_over_text = game_over_font.render("Game Over", True, WHITE)
        screen.blit(game_over_text, ((WIDTH - game_over_text.get_width()) // 2, 50))

        restart_button = pygame.Rect((WIDTH // 2 - 100), (HEIGHT // 2), 200, 50)
        exit_button = pygame.Rect((WIDTH // 2 - 100), (HEIGHT // 2 + 60), 200, 50)

        pygame.draw.rect(screen, GREEN, restart_button)
        restart_text = button_font.render("Restart", True, WHITE)
        screen.blit(restart_text, (restart_button.x + (restart_button.width - restart_text.get_width()) // 2,
                                   restart_button.y + (restart_button.height - restart_text.get_height()) // 2))

        pygame.draw.rect(screen, BRIGHT_RED, exit_button)
        exit_text = button_font.render("Exit", True, WHITE)
        screen.blit(exit_text, (exit_button.x + (exit_button.width - exit_text.get_width()) // 2,
                                exit_button.y + (exit_button.height - exit_text.get_height()) // 2))

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            if restart_button.collidepoint(mouse_pos):
                reset_game()
            if exit_button.collidepoint(mouse_pos):
                running = False

    pygame.display.flip()

# Quit
pygame.quit()
sys.exit()

