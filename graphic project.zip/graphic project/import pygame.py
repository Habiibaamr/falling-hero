import pygame
import sys
import random

# Initialize Pygame
pygame.init()

# Window setup
WIDTH, HEIGHT = 400, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Falling Hero")

# Colors
BLACK = (0, 0, 0)
RED = (255, 50, 50)
GRAY = (180, 180, 180)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BRIGHT_RED = (255, 0, 0)

# Load background and player images
background_image = pygame.image.load("C:/Users/alghad\Documents/Computer Graphics/graphic project/a5b2805f7b11d037b6ec5748b2bf6f50.jpg")
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

player_image = pygame.image.load("C:/Users/alghad/Documents/Computer Graphics/graphic project/vecteezy_cute-cat-hero-icon-character_44627587.png")
player_image = pygame.transform.scale(player_image, (40, 40))  # Player image size

cloud_image = pygame.image.load("C:/Users/alghad/Documents/Computer Graphics/graphic project/—Pngtree—angry cloud design annoyed illustration_6530414.png")
cloud_image = pygame.transform.scale(cloud_image, (60, 40))  # Bigger cloud, but collision size will stay small

star_image = pygame.image.load("C:/Users/alghad/Documents/Computer Graphics/graphic project/—Pngtree—star cartoon stars cute stars_3816650.png")
star_image = pygame.transform.scale(star_image, (40, 40))

# Fonts
font = pygame.font.SysFont(None, 36)
game_over_font = pygame.font.SysFont(None, 72)
button_font = pygame.font.SysFont(None, 48)

# Clock
clock = pygame.time.Clock()
FPS = 60

# Player setup
player_full_width, player_full_height = 40, 40
player_collision_width, player_collision_height = 28, 28
player_x = WIDTH // 2 - player_full_width // 2
player_y = 150
player_rect = pygame.Rect(player_x + 6, player_y + 6, player_collision_width, player_collision_height)
player_speed_x = 5

# Obstacle setup
obstacle_width, obstacle_height = 50, 20  # collision box size (not the cloud image size)
obstacle_speed = 5
obstacles = []

def create_obstacle():
    x = random.randint(0, WIDTH - obstacle_width)
    y = HEIGHT + random.randint(20, 100)
    return pygame.Rect(x, y, obstacle_width, obstacle_height)

for _ in range(5):
    obstacles.append(create_obstacle())

# Star setup
star_size = 20
stars = []

def create_star():
    x = random.randint(0, WIDTH - star_size)
    y = HEIGHT + random.randint(100, 400)
    return pygame.Rect(x, y, star_size, star_size)

for _ in range(3):
    stars.append(create_star())

# Load sounds
star_collect_sound = pygame.mixer.Sound("C:/Users/alghad/Documents/Computer Graphics/graphic project/coin-recieved-230517.mp3")
game_over_sound = pygame.mixer.Sound("C:/Users/alghad/Documents/Computer Graphics/graphic project/game-over-2-sound-effect-230463.mp3")

# Score
score = 0
star_score = 0
game_over_displayed = False

def reset_game():
    global score, star_score, player_rect, obstacles, stars, game_over_displayed
    score = 0
    star_score = 0
    player_rect = pygame.Rect(WIDTH // 2 - player_full_width // 2 + 6, 150 + 6, player_collision_width, player_collision_height)
    obstacles.clear()
    for _ in range(5):
        obstacles.append(create_obstacle())
    stars.clear()
    for _ in range(3):
        stars.append(create_star())
    game_over_displayed = False

# Game loop
running = True
while running:
    clock.tick(FPS)
    score += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if not game_over_displayed:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_rect.left > 0:
            player_rect.x -= player_speed_x
        if keys[pygame.K_RIGHT] and player_rect.right < WIDTH:
            player_rect.x += player_speed_x

        # Move obstacles upward
        for obs in obstacles:
            obs.y -= obstacle_speed
            if obs.y + obstacle_height < 0:
                obs.y = HEIGHT + random.randint(20, 100)
                obs.x = random.randint(0, WIDTH - obstacle_width)
            if player_rect.colliderect(obs):
                if not game_over_displayed:
                    game_over_sound.play()
                    pygame.time.delay(int(game_over_sound.get_length() * 1000))
                    game_over_displayed = True
                    continue

        # Move stars upward
        for star in stars:
            star.y -= obstacle_speed
            if star.y + star_size < 0:
                star.y = HEIGHT + random.randint(100, 400)
                star.x = random.randint(0, WIDTH - star_size)
            if player_rect.colliderect(star):
                star_score += 50
                stars.remove(star)
                stars.append(create_star())
                star_collect_sound.play()

        # Draw everything
        screen.blit(background_image, (0, 0))
        screen.blit(player_image, (player_rect.x - 6, player_rect.y - 6))  # Adjust player image
        
        # Draw stars
        for star in stars:
            screen.blit(star_image, (star.x, star.y))

        for obs in obstacles:
            # Draw the cloud image at the obstacle's position
            screen.blit(cloud_image, (obs.x - 5, obs.y - 10))  # Adjust so it looks centered

        #for star in stars:
            #pygame.draw.rect(screen, YELLOW, star)

        # Draw score
        score_text = font.render(f"Score: {score}", True, WHITE)
        bonus_text = font.render(f"Stars: {star_score}", True, YELLOW)
        screen.blit(score_text, (10, 10))
        screen.blit(bonus_text, (10, 40))

    else:
        # Draw Game Over screen
        screen.blit(background_image, (0, 0))
        game_over_text = game_over_font.render("Game Over", True, WHITE)
        screen.blit(game_over_text, ((WIDTH - game_over_text.get_width()) // 2, 50))

        restart_button = pygame.Rect((WIDTH // 2 - 100), (HEIGHT // 2), 200, 50)
        exit_button = pygame.Rect((WIDTH // 2 - 100), (HEIGHT // 2 + 60), 200, 50)

        pygame.draw.rect(screen, GREEN, restart_button)
        restart_text = button_font.render("Restart", True, WHITE)
        screen.blit(restart_text, (restart_button.x + (restart_button.width - restart_text.get_width()) // 2,
                                   restart_button.y + (restart_button.height - restart_text.get_height()) // 2))

        pygame.draw.rect(screen, BRIGHT_RED, exit_button)
        exit_text = button_font.render("Exit", True, WHITE)
        screen.blit(exit_text, (exit_button.x + (exit_button.width - exit_text.get_width()) // 2,
                                exit_button.y + (exit_button.height - exit_text.get_height()) // 2))

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            if restart_button.collidepoint(mouse_pos):
                reset_game()
            if exit_button.collidepoint(mouse_pos):
                running = False

    pygame.display.flip()

# Quit
pygame.quit()
sys.exit()
